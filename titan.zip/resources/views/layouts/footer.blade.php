<footer class="page-footer">
    <div class="font-13">2019 © <b>TITAN</b> - Save your time, choose the best</div>
    <div>
        <a class="px-3 pl-4" href="#" target="_blank">Purchase</a>
    </div>
    <div class="to-top"><i class="fa fa-angle-double-up"></i></div>
</footer>