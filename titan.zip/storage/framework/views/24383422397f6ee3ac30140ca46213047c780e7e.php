<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('master/vendors/daterangepicker/daterangepicker.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- START PAGE CONTENT-->
        <div class="page-content fade-in-up">
            <div class="row mb-4">
                <div class="col-lg-4 col-md-6">
                    <div class="card mb-4">
                        <div class="card-body flexbox-b">
                            <div class="easypie mr-4" data-percent="<?php if($return['total_projects'] > 0): ?><?php echo e($return['completed_projects']*100/$return['total_projects']); ?><?php endif; ?>" data-bar-color="#5c6bc0" data-size="80" data-line-width="8">
                                <span class="easypie-data font-26 text-primary"><i class="ti-book"></i></span>
                            </div>
                            <div class="mr-5">
                                <h3 class="font-strong text-primary"><?php echo e($return['total_projects']); ?></h3>
                                <div class="text-muted">TOTAL PROJECTS</div>
                            </div class="mr-3">                            
                            <div>
                                <h3 class="font-strong text-primary"><?php echo e($return['completed_projects']); ?></h3>
                                <div class="text-muted">COMPLETED PROJECTS</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card mb-4">
                        <div class="card-body flexbox-b">
                            <div class="easypie mr-4" data-percent="<?php if($return['total_requests'] > 0): ?><?php echo e($return['approved_requests']*100/$return['total_requests']); ?><?php endif; ?>" data-bar-color="#ff4081" data-size="80" data-line-width="8">
                                <span class="easypie-data text-pink" style="font-size:32px;"><i class="ti-help"></i></span>
                            </div>
                            <div class="mr-5">
                                <h3 class="font-strong text-pink"><?php echo e($return['total_requests']); ?></h3>
                                <div class="text-muted">TOTAL REQUESTS</div>
                            </div>
                            <div class="mr-3">
                                <h3 class="font-strong text-pink"><?php echo e($return['approved_requests']); ?></h3>
                                <div class="text-muted">APPRPVED REQUESTS</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card mb-4">
                        <div class="card-body flexbox-b">
                            <div class="easypie mr-4" data-percent="<?php if($return['total_requested_money'] > 0): ?><?php echo e($return['total_approved_money']*100/$return['total_requested_money']); ?><?php endif; ?>" data-bar-color="#18C5A9" data-size="80" data-line-width="8">
                                <span class="easypie-data text-success" style="font-size:32px;"><i class="la la-money"></i></span>
                            </div>
                            <div class="mr-5">
                                <h3 class="font-strong text-success"><?php echo e($return['total_requested_money']); ?></h3>
                                <div class="text-muted">REQUESTED MONEY</div>
                            </div>
                            <div class="mr-3">
                                <h3 class="font-strong text-success"><?php echo e($return['total_approved_money']); ?></h3>
                                <div class="text-muted">APPROVED MONEY</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="ibox bg-success">
                        <div class="ibox-body">
                            <h2 class="mb-1 text-white"><?php echo e($return['today_money']); ?></h2>
                            <div class="text-dark">TODAY REQUESTS</div><i class="la la-money widget-stat-icon text-white"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="ibox bg-primary">
                        <div class="ibox-body">
                            <h2 class="mb-1 text-white"><?php echo e($return['week_money']); ?></h2>
                            <div class="text-dark">WEEK REQUESTS</div><i class="la la-money widget-stat-icon text-white"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="ibox bg-info">
                        <div class="ibox-body">
                            <h2 class="mb-1 text-white"><?php echo e($return['month_money']); ?></h2>
                            <div class="text-dark">MONTH REQUESTS</div><i class="la la-money widget-stat-icon text-white"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="ibox bg-warning">
                        <div class="ibox-body">
                            <h2 class="mb-1 text-white"><?php echo e($return['year_money']); ?></h2>
                            <div class="text-dark">YEAR REQUESTS</div><i class="la la-money widget-stat-icon text-white"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="ibox">
                        <div class="ibox-head">
                            <div class="ibox-title">Finances</div>
                            <form action="" class="form-inline" method="post" id="search_form">
                                <?php echo csrf_field(); ?>
                                <label for="period">Date: </label>
                                <input type="text" class="form-control form-control-sm mr-sm-2 ml-3" name="period" id="period" autocomplete="off" value="<?php echo e($period); ?>" style="width:200px;">
                                <button type="submit" class="btn btn-primary btn-sm">Search</button>
                                <button type="button" class="btn btn-success btn-sm mr-1" id="btn-reset">Reset</button>
                            </form>
                        </div>
                        <div class="ibox-body">
                            <div>
                                <canvas id="finance_chart" style="height:400px;"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="ibox ibox-fullheight">
                        <div class="ibox-head">
                            <div class="ibox-title">Recent Courses</div>
                        </div>
                        <div class="ibox-body table-responsive">
                            <table class="table table-bordered table-hover" id="coursesTable" style="min-width:500px;">
                                <thead class="thead-default thead-lg">
                                    <tr>
                                        <th>Task</th>
                                        <th>Status</th>
                                        <th>Project</th>
                                        <th>Completion</th>
                                        <th>Due Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $recent_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                            
                                        <tr>
                                            <td class="name"><a href="<?php echo e(route('course.detail', $item->id)); ?>"><?php echo e($item->name); ?></a></td>
                                            <td class="status" data-value="<?php echo e($item->status); ?>">
                                                <?php if($item->status == 1): ?>
                                                    <span class="badge badge-primary badge-pill">New</span>
                                                <?php elseif($item->status == 2): ?>
                                                    <span class="badge badge-secondary badge-pill">In Progress</span>
                                                <?php elseif($item->status == 3): ?>
                                                    <span class="badge badge-info badge-pill">On Hold</span>
                                                <?php elseif($item->status == 4): ?>
                                                    <span class="badge badge-success badge-pill">Completed</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="project" data-value="<?php echo e($item->project_id); ?>"><?php if(isset($item->project->name)): ?><?php echo e($item->project->name); ?><?php endif; ?></td>
                                            <td class="prog" data-value="<?php echo e($item->progress); ?>">
                                                <div class="progress">
                                                    <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo e($item->progress); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($item->progress); ?>%;"><?php echo e($item->progress); ?>%</div>
                                                </div>
                                            </td>
                                            <td class="due_to"><?php echo e($item->due_to); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="ibox">
                        <div class="ibox-head">
                            <div class="ibox-title">Recent Notifications</div>
                        </div> 
                        <div class="ibox-body">                        
                            <ul class="media-list media-list-divider scroller" data-height="285px">
                                <?php $__currentLoopData = $recent_notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="media py-2">
                                        <div class="media-img">
                                            <span class="btn-icon-only btn-circle bg-primary-50 text-primary">
                                                <?php switch($item->type):
                                                    case ("create_project"): ?>
                                                        <i class="ti-check"></i>
                                                        <?php break; ?>
                                                    <?php case ("new_request"): ?>
                                                        <i class="fa fa-file-excel-o"></i>
                                                        <?php break; ?>
                                                    <?php case ("exceed_limit"): ?>
                                                        <i class="fa fa-money"></i>
                                                        <?php break; ?>
                                                    <?php case ("new_course"): ?>
                                                        <i class="fa fa-list"></i>
                                                        <?php break; ?>
                                                    <?php case ("completed"): ?>
                                                        <i class="ti-announcement"></i>
                                                        <?php break; ?>
                                                    <?php default: ?>
                                                        <i class="fa fa-file-list"></i>
                                                <?php endswitch; ?>   
                                            </span>
                                        </div>
                                        <div class="media-body">
                                            <div class="media-heading">
                                                <?php echo e(ucwords($item->type)); ?>

                                                
                                            </div>
                                            <div class="font-13 text-light"><?php echo e($item->content); ?></div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>                       
                    </div>
                </div>
            </div>
        </div>
        <!-- END PAGE CONTENT-->
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- PAGE LEVEL PLUGINS-->
    <script src="<?php echo e(asset('master/vendors/chart.js/dist/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('master/vendors/jquery.easy-pie-chart/dist/jquery.easypiechart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('master/vendors/daterangepicker/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('master/vendors/daterangepicker/jquery.daterangepicker.min.js')); ?>"></script>
    
    <script>
        var lineData = {
            labels: <?php echo json_encode($key_array); ?>,
            datasets: [
                {
                    label: "Requested Money",
                    backgroundColor: 'rgba(213,217,219, 0.5)',
                    borderColor: 'rgba(213,217,219, 1)',
                    pointBorderColor: "#fff",
                    data: <?php echo json_encode($money_array); ?>,
                    // fill: false,
                }
            ]
        };
        var lineOptions = {
            legend: {
                display: false,
            },
            responsive: true,
            maintainAspectRatio: false
        };
        var ctx = document.getElementById("finance_chart").getContext("2d");
        new Chart(ctx, {type: 'line', data: lineData, options:lineOptions});
        $(function(){
            $('.easypie').each(function(){
                $(this).easyPieChart({
                trackColor: $(this).attr('data-trackColor') || '#f2f2f2',
                scaleColor: false,
                });
            });
            $("#period").dateRangePicker();
            $("#btn-reset").click(function(){
                $("#period").val('');
            })
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\TITAN\titan\resources\views/manager/home.blade.php ENDPATH**/ ?>