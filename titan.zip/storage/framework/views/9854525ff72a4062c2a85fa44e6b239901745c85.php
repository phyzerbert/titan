<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('master/vendors/bootstrap-datepicker/dist/css/bootstrap-datepicker3.min.css')); ?>" rel="stylesheet" />    
    <link href="<?php echo e(asset('master/vendors/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $role = Auth::user()->role->slug;
    ?>
    <div class="content-wrapper">
        <!-- START PAGE CONTENT-->
        <div class="page-heading">
            <h1 class="page-title">My Courses</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/"><i class="la la-home font-20"></i></a></li>
                <li class="breadcrumb-item">Mycourses</li>
            </ol>
        </div>
        <div class="page-content fade-in-up">
            <div class="row">
                <div class="col-lg-10 mx-auto">
                    <div class="ibox">
                        <div class="ibox-body">
                            <div>
                                <h3 class="float-left mb-1">My Courses</h3>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover" id="coursesTable">
                                    <thead class="thead-default thead-lg">
                                        <tr>
                                            <th class="text-center">No</th>
                                            <th>Task</th>
                                            <th>Status</th>
                                            <th>Project</th>
                                            <th>Completion</th>
                                            <th>Due Date</th>
                                            <th>Created Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="text-center"><?php echo e((($courses->currentPage() - 1 ) * $courses->perPage() ) + $loop->iteration); ?></td>
                                                <td class="name"><?php echo e($item->name); ?></td>
                                                <td class="status" data-value="<?php echo e($item->status); ?>">
                                                    <?php if($item->status == 1): ?>
                                                        <span class="badge badge-primary badge-pill">New</span>
                                                    <?php elseif($item->status == 2): ?>
                                                        <span class="badge badge-secondary badge-pill">In Progress</span>
                                                    <?php elseif($item->status == 3): ?>
                                                        <span class="badge badge-info badge-pill">On Hold</span>
                                                    <?php elseif($item->status == 4): ?>
                                                        <span class="badge badge-success badge-pill">Completed</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="project" data-value="<?php echo e($item->project_id); ?>"><?php if(isset($item->project->name)): ?><?php echo e($item->project->name); ?><?php endif; ?></td>
                                                <td class="prog" data-value="<?php echo e($item->progress); ?>"><?php echo e($item->progress); ?>%</td>
                                                <td class="due_to"><?php echo e($item->due_to); ?></td>
                                                <td class="created_at"><?php echo e($item->created_at); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody> 
                                </table>                                   
                                <div class="clearfix">
                                    <div class="float-left" style="margin: 0;">
                                        <p>Total <strong style="color: red"><?php echo e($courses->total()); ?></strong> Courses</p>
                                    </div>
                                    <div class="float-right" style="margin: 0;">
                                        <?php echo $courses->appends([])->links(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END PAGE CONTENT-->
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(asset('master/vendors/moment/min/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('master/vendors/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>    
    <script src="<?php echo e(asset('master/vendors/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js')); ?>"></script>
    <script>
        $(document).ready(function(){

        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\TITAN\titan\resources\views/member/course.blade.php ENDPATH**/ ?>