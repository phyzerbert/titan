<!-- START HEADER-->
<header class="header">
    <div class="page-brand">
        <a href="/" class="mx-auto">
            <span class="brand"><?php echo e(config('app.name')); ?></span>
            <span class="brand-mini"><?php echo e(Auth::user()->role->name); ?></span>
        </a>
    </div>
    <div class="flexbox flex-1">
        <!-- START TOP-LEFT TOOLBAR-->
        <ul class="nav navbar-toolbar">
            <li>
                <a class="nav-link sidebar-toggler js-sidebar-toggler" href="javascript:;">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
            </li>
        </ul>
        <!-- END TOP-LEFT TOOLBAR-->
        <!-- START TOP-RIGHT TOOLBAR-->
        <?php
            $recent_messages = \App\Models\Notification::orderBy('created_at', 'desc')->limit(10)->get();
        ?>
        <ul class="nav navbar-toolbar">
            <li class="dropdown dropdown-notification">
                <a class="nav-link dropdown-toggle toolbar-icon" data-toggle="dropdown" href="javascript:;"><i class="ti-bell rel"><span class="notify-signal"></span></i></a>
                <div class="dropdown-menu dropdown-menu-right dropdown-menu-media" style="left:120px !important">
                    <div class="dropdown-arrow"></div>
                    <div class="p-3">
                        <ul class="timeline scroller" data-height="250px">
                            <?php $__currentLoopData = $recent_messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a 
                                    <?php switch($item->type):
                                        case ("create_project"): ?>
                                            href="<?php echo e(route('project.index')); ?>"
                                            <?php break; ?>
                                        <?php case ("new_request"): ?>
                                            href="<?php echo e(route('request.index')); ?>"
                                            <?php break; ?>
                                        <?php case ("exceed_limit"): ?>
                                            href="<?php echo e(route('request.index')); ?>"
                                            <?php break; ?>
                                        <?php case ("new_course"): ?>
                                            href="<?php echo e(route('course.detail', $item->link)); ?>"
                                            <?php break; ?>
                                        <?php case ("completed"): ?>
                                            href="<?php echo e(route('course.detail', $item->link)); ?>"
                                            <?php break; ?>
                                        <?php default: ?>
                                            href="<?php echo e(route('project.index')); ?>"
                                    <?php endswitch; ?>                                
                                >
                                    <li class="timeline-item">
                                        <?php switch($item->type):
                                            case ("create_project"): ?>
                                                <i class="ti-check timeline-icon"></i>
                                                <?php break; ?>
                                            <?php case ("new_request"): ?>
                                                <i class="fa fa-file-excel-o timeline-icon"></i>
                                                <?php break; ?>
                                            <?php case ("exceed_limit"): ?>
                                                <i class="fa fa-file-excel-o timeline-icon"></i>
                                                <?php break; ?>
                                            <?php case ("new_course"): ?>
                                                <i class="fa fa-file-excel-o timeline-icon"></i>
                                                <?php break; ?>
                                            <?php case ("completed"): ?>
                                                <i class="ti-announcement timeline-icon"></i>
                                                <?php break; ?>
                                            <?php default: ?>
                                                <i class="fa fa-file-excel-o timeline-icon"></i>
                                        <?php endswitch; ?>                                    
                                        <?php echo e($item->content); ?>

                                    </li>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </ul>
                    </div>
                </div>
            </li>
            <li class="dropdown dropdown-user">
                <a class="nav-link dropdown-toggle link" data-toggle="dropdown">
                    <span><?php echo e(Auth::user()->name); ?></span>
                    <img src="<?php if(isset(Auth::user()->picture)): ?><?php echo e(asset(Auth::user()->picture)); ?> <?php else: ?> <?php echo e(asset('images/avatar128.png')); ?> <?php endif; ?>" alt="User Image" />
                </a>
                <div class="dropdown-menu dropdown-arrow dropdown-menu-right admin-dropdown-menu">
                    <div class="dropdown-arrow"></div>
                    <div class="dropdown-header">
                        <div class="admin-avatar">
                            <img src="<?php if(isset(Auth::user()->picture)): ?><?php echo e(asset(Auth::user()->picture)); ?> <?php else: ?> <?php echo e(asset('images/avatar128.png')); ?> <?php endif; ?>" alt="User Image" />
                        </div>
                        <div>
                            <h5 class="font-strong text-white"><?php echo e(Auth::user()->name); ?></h5>
                            <div>
                                <span class="admin-badge"><i class="ti-alarm-clock mr-2"></i><?php echo e(Auth::user()->role->name); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="admin-menu-features">
                        <a class="admin-features-item" href="<?php echo e(route('profile')); ?>"><i class="ti-user"></i>
                            <span>PROFILE</span>
                        </a>
                        <a class="admin-features-item" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                            <i class="ti-shift-right"></i>
                            <span>Logout</span>
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"> <?php echo csrf_field(); ?> </form>
                    </div>
                </div>
            </li>
        </ul>
        <!-- END TOP-RIGHT TOOLBAR-->
    </div>
</header>
<!-- END HEADER--><?php /**PATH E:\TITAN\titan\resources\views/layouts/header.blade.php ENDPATH**/ ?>