<?php echo e($slot); ?>

<?php /**PATH E:\TITAN\titan\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>