<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- START PAGE CONTENT-->
        <div class="page-header">
            <div class="ibox flex-1">
                <div class="ibox-body">
                    <div class="flexbox">
                        <div class="flexbox-b">
                            <div class="ml-5 mr-5">
                                <img class="img-circle" src="<?php if(isset(Auth::user()->picture)): ?><?php echo e(asset(Auth::user()->picture)); ?> <?php else: ?> <?php echo e(asset('images/avatar128.png')); ?> <?php endif; ?>" alt="image" width="110" />
                            </div>
                            <div>
                                <h4><?php echo e($user->name); ?></h4>
                                <div>
                                    <span class="mr-3">
                                        <span class="badge badge-primary badge-circle mr-2 font-14" style="height:30px;width:30px;"><i class="ti-briefcase"></i></span><?php echo e($user->role->name); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="d-inline-flex">
                            <?php if($user->role->slug == 'project_manager'): ?>
                                <div class="px-4 text-center">
                                    <div class="text-muted font-13">PROJECTS</div>
                                    <div class="h2 mt-2"><?php echo e($user->projects()->count()); ?></div>
                                </div>
                            <?php elseif($user->role->slug == 'course_member'): ?>
                                <div class="px-4 text-center">
                                    <div class="text-muted font-13">COURSES</div>
                                    <div class="h2 mt-2"><?php echo e($user->courses()->count()); ?></div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container page-content fade-in-up">
            <div class="row">
                <div class="col-md-10 mx-auto">
                    <div class="ibox ibox-fullheight">
                        <div class="ibox-head">
                            <div class="ibox-title">My Profile</div>
                        </div>
                        <form class="form-info" action="<?php echo e(route('save_profile')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="ibox-body">
                                <div class="form-group mb-4">
                                    <label>Name</label>
                                    <input class="form-control" type="text" name="name" value="<?php echo e($user->name); ?>" placeholder="Username">
                                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-group mb-4">
                                    <label>Email</label>
                                    <input class="form-control" type="email" name="email" value="<?php echo e($user->email); ?>" placeholder="Email address">
                                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                        <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>                                
                                <div class="form-group mb-4">
                                    <label>Picture</label>
                                    <input class="form-control form-control-sm" type="file" name="picture" accept="image/*" />
                                    <?php if ($errors->has('picture')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('picture'); ?>
                                        <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                                <div class="form-group mb-4">
                                    <label>Password</label>
                                    <input class="form-control" type="password" name="password" placeholder="Password">
                                </div>                                
                                <div class="form-group mb-4">
                                    <label>Confirm Password</label>
                                    <input class="form-control" type="password" name="password-confirm" placeholder="Confirm Password">
                                </div>
                            </div>
                            <div class="ibox-footer text-right">
                                <button class="btn btn-secondary mr-2" type="reset">Cancel</button>
                                <button class="btn btn-info" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- END PAGE CONTENT-->
        <footer class="page-footer">
            <div class="font-13">2018 © <b>Adminca</b> - Save your time, choose the best</div>
            <div>
                <a class="px-3 pl-4" href="http://themeforest.net/item/adminca-responsive-bootstrap-4-3-angular-4-admin-dashboard-template/20912589" target="_blank">Purchase</a>
                <a class="px-3" href="../../../documentation.html" target="_blank">Docs</a>
            </div>
            <div class="to-top"><i class="fa fa-angle-double-up"></i></div>
        </footer>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\TITAN\titan\resources\views/profile.blade.php ENDPATH**/ ?>