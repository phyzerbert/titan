<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- START PAGE CONTENT-->
        <div class="page-heading">
            <h1 class="page-title">User Management</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/"><i class="la la-home font-20"></i></a></li>
                <li class="breadcrumb-item">User Management</li>
            </ol>
        </div>
        <div class="page-content fade-in-up">
            <div class="ibox">
                <div class="ibox-body">
                    <div class="text-right mb-4">
                        <button type="button" id="btn-add" class="btn btn-primary btn-fix"><span class="btn-icon"><i class="ti-plus"></i>Add New</span></button>
                    </div>
                    <div class="table-responsive row">
                        <table class="table table-bordered table-hover" id="usersTable">
                            <thead class="thead-default thead-lg">
                                <tr>
                                    <th class="text-center">No</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Created at</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e((($data->currentPage() - 1 ) * $data->perPage() ) + $loop->iteration); ?></td>
                                        <td class="name"><?php echo e($item->name); ?></td>
                                        <td class="email"><?php echo e($item->email); ?></td>
                                        <td><?php echo e($item->role->name); ?></td>
                                        <td><?php echo e($item->created_at); ?></td>
                                        <td class="text-center py-1">
                                            <a class="btn btn-sm btn-info btn-fix btn-edit" data-id="<?php echo e($item->id); ?>"><span class="btn-icon text-white"><i class="la la-pencil"></i>Edit</span></a>
                                            <a href="<?php echo e(route('user.delete', $item->id)); ?>" class="btn btn-sm btn-danger btn-fix" onclick="return window.confirm('Are you sure?')"><span class="btn-icon text-white"><i class="la la-trash"></i>Remove</span></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="clearfix">
                            <div class="float-left" style="margin: 0;">
                                <p>Total <strong style="color: red"><?php echo e($data->total()); ?></strong> Users</p>
                            </div>
                            <div class="float-right" style="margin: 0;">
                                <?php echo $data->appends([])->links(); ?>

                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
        <!-- END PAGE CONTENT-->
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
    </div>

    <div class="modal fade" id="addModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('user.create')); ?>" method="post" id="add_form">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="role_id" value="3" />
                    <div class="modal-header">
                        <h4 class="modal-title">Add New Project Manager</h4>
                        <button type="button" class="close" data-dismiss="modal">×</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="control-label text-right mt-1">Name<span class="text-danger">*</span></label>
                            <input class="form-control" type="text" name="name" id="add_name" placeholder="Name" required>
                            <span id="name_error" class="invalid-feedback">
                                <strong></strong>
                            </span>
                        </div>

                        <div class="form-group">
                            <label class="control-label text-right mt-1">Email Address<span class="text-danger">*</span></label>
                            <input class="form-control" type="email" name="email" id="add_email" placeholder="Email Address" required >
                            <span id="email_error" class="invalid-feedback">
                                <strong></strong>
                            </span>
                        </div>

                        <div class="form-group">
                            <label class="control-label text-right mt-1">Role<span class="text-danger">*</span></label>
                            <select class="form-control role" type="email" name="role_id" id="add_role" required >
                                <option value="4">Course Member</option>
                                <option value="3">Project Manager</option>
                                <option value="2">Accountant</option>
                                <option value="1">Admin</option>
                            </select>
                            <span id="role_error" class="invalid-feedback">
                                <strong></strong>
                            </span>
                        </div>

                        <div class="form-group password-field">
                            <label class="control-label">Password</label>
                            <input type="password" name="password" id="add_password" class="form-control" placeholder="Password">
                            <span id="password_error" class="invalid-feedback">
                                <strong></strong>
                            </span>
                        </div>
    
                        <div class="form-group password-field">
                            <label class="control-label">Password Confirm</label>
                            <input type="password" name="password_confirmation" id="add_confirmpassword" class="form-control" placeholder="Password Confirm">
                        </div>

                    </div>
                    
                    <div class="modal-footer">    
                        <button type="submit" class="btn btn-primary ml-2">Save</button>                       
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('user.edit')); ?>" method="post" id="edit_form">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" class="id" name="id" />
                    <div class="modal-header">
                        <h4 class="modal-title">Edit User</h4>
                        <button type="button" class="close" data-dismiss="modal">×</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="control-label text-right mt-1">Name<span class="text-danger">*</span></label>
                            <input class="form-control name" type="text" name="name" id="edit_name" placeholder="Name" required>
                            <span id="name_error" class="invalid-feedback">
                                <strong></strong>
                            </span>
                        </div>

                        <div class="form-group">
                            <label class="control-label text-right mt-1">Email Address<span class="text-danger">*</span></label>
                            <input class="form-control email" type="email" name="email" id="edit_email" placeholder="Email Address" required >
                            <span id="email_error" class="invalid-feedback">
                                <strong></strong>
                            </span>
                        </div>

                        <div class="form-group password-field">
                            <label class="control-label">Password</label>
                            <input type="password" name="password" id="edit_password" class="form-control" placeholder="Password">
                            <span id="password_error" class="invalid-feedback">
                                <strong></strong>
                            </span>
                        </div>
    
                        <div class="form-group password-field">
                            <label class="control-label">Password Confirm</label>
                            <input type="password" name="password_confirmation" id="edit_confirmpassword" class="form-control" placeholder="Password Confirm">
                        </div>

                    </div>
                    
                    <div class="modal-footer">    
                        <button type="submit" class="btn btn-primary ml-2">Save</button>                       
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            $("#btn-add").click(function(){
                $("#addModal").modal();
            });

            $(".btn-edit").click(function(){
                let id = $(this).data('id');
                let name = $(this).parents('tr').find('.name').text().trim();
                let email = $(this).parents('tr').find('.email').text().trim();

                $("#edit_form .id").val(id);
                $("#edit_form .name").val(name);
                $("#edit_form .email").val(email);
                $("#editModal").modal();
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\TITAN\titan\resources\views/admin/user.blade.php ENDPATH**/ ?>