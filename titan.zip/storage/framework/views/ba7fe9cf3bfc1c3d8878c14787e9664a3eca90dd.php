<!-- START SIDEBAR-->
<?php
    $page = config('site.c_page');
    $role = Auth::user()->role->slug;
?>
<nav class="page-sidebar" id="sidebar">
    <div id="sidebar-collapse">
        <ul class="side-menu metismenu">            
            <li class="<?php if($page == 'home'): ?> active <?php endif; ?>"><a href="<?php echo e(route('home')); ?>"><i class="sidebar-item-icon ti-home"></i><span class="nav-label">Dashboard</span></a></li>
            <?php if($role != 'course_member'): ?>
                <li class="<?php if($page == 'projects'): ?> active <?php endif; ?>"><a href="<?php echo e(route('project.index')); ?>"><i class="sidebar-item-icon ti-book"></i><span class="nav-label">Project Management</span></a></li>
            <?php endif; ?>
            <?php if($role == 'course_member'): ?>
                <li class="<?php if($page == 'courses'): ?> active <?php endif; ?>"><a href="<?php echo e(route('member.course')); ?>"><i class="sidebar-item-icon ti-list"></i><span class="nav-label">My Courses</span></a></li>
            <?php endif; ?>
            <li class="<?php if($page == 'requests'): ?> active <?php endif; ?>"><a href="<?php echo e(route('request.index')); ?>"><i class="sidebar-item-icon ti-money"></i><span class="nav-label">Request Management</span></a></li>
            <?php if($role == 'admin'): ?>
                <li class="<?php if($page == 'users'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user.index')); ?>"><i class="sidebar-item-icon ti-user"></i><span class="nav-label">User Management</span></a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
<!-- END SIDEBAR--><?php /**PATH E:\TITAN\titan\resources\views/layouts/aside.blade.php ENDPATH**/ ?>