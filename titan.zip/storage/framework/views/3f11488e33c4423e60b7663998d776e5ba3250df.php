<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('master/vendors/bootstrap-datepicker/dist/css/bootstrap-datepicker3.min.css')); ?>" rel="stylesheet" />  
    <link href="<?php echo e(asset('master/vendors/select2/dist/css/select2.min.css')); ?>" rel="stylesheet" />
    <style>
        span.select2-container{width: 100% !important;}
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $role = Auth::user()->role->slug;
    ?>
    <div class="content-wrapper">
        <!-- START PAGE CONTENT-->
        <div class="page-heading">
            <h1 class="page-title">Course Overview</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/"><i class="la la-home font-20"></i></a></li>
                <li class="breadcrumb-item">Project</li>
                <li class="breadcrumb-item">Course Overview</li>
            </ol>
        </div>
        <div class="page-content fade-in-up">
            <div class="row">
                <div class="col-xl-10 mx-auto">
                    <div class="ibox">
                        <div class="ibox-body">
                            <div class="d-flex justify-content-between m-b-20">
                                <div>
                                    <h3 class="m-0"><?php echo e($course->name); ?></h3>
                                    <div><?php echo e($course->description); ?></div>
                                </div>
                            </div>
                            <div class="row mt-5">
                                <div class="col-3 pl-3">
                                    <h6 class="mb-3">Course Created</h6>
                                    <span class="h2 mr-3"><i class="fa fa-calendar text-primary h1 mb-0 mr-2"></i>
                                        <span><?php echo e(date('Y-m-d', strtotime($course->created_at))); ?></span>
                                    </span>
                                </div>
                                <div class="col-3 pl-3">
                                    <h6 class="mb-3">Course Status</h6>
                                    <span class="h2 mr-3"><i class="fa fa-list text-primary h1 mb-0 mr-2"></i>
                                        <span><?php echo e($course->status); ?></span>
                                    </span>
                                </div>
                                <div class="col-3 pl-4">
                                    <h6 class="mb-3">Course Members</h6>
                                    <span class="h2 mr-3"><i class="fa fa-users text-primary h1 mb-0 mr-2"></i>
                                        <span><?php echo e($course->members()->count()); ?></span>
                                    </span>
                                </div>                              
                                <div class="col-3 pl-4">
                                    <h6 class="mb-3">Course Progress</h6>
                                    <span class="h2 mr-3"><i class="fa fa-spinner text-primary h1 mb-0 mr-2"></i>
                                        <span><?php echo e($course->progress); ?>%</span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="ibox">
                        <div class="ibox-head">
                            <div class="ibox-title">COURSE TEAM</div>
                            <?php if($role == 'project_manager'): ?>                                
                                <a href="#" id="btn-add-member" class="btn btn-sm btn-primary btn-fix float-right mb-2"><span class="btn-icon"><i class="ti-plus"></i>Add Member</span></a>
                            <?php endif; ?>
                        </div>
                        <div class="ibox-body">
                            <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto;"><ul class="media-list media-list-divider mr-2 scroller">
                                <?php $__currentLoopData = $course->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="media align-items-center py-1">
                                        <a class="media-img" href="javascript:;">
                                            <img class="img-circle" src="<?php if(isset($member->picture)): ?><?php echo e(asset($member->picture)); ?> <?php else: ?> <?php echo e(asset('images/avatar128.png')); ?> <?php endif; ?>" alt="image" width="45">
                                        </a>
                                        <div class="media-body d-flex align-items-center">
                                            <div class="flex-1">
                                                <div class="media-heading"><?php echo e($member->name); ?></div><small class="text-muted"><a href="mailto:<?php echo e($member->email); ?>"><?php echo e($member->email); ?></a></small></div>
                                            <span class="badge badge-success badge-pill">Member</span>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul><div class="slimScrollBar" style="background: rgb(113, 128, 143); width: 4px; position: absolute; top: 28px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 552.381px;"></div><div class="slimScrollRail" style="width: 4px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.9; z-index: 90; right: 1px;"></div></div>
                        </div>
                    </div>
                    <div class="ibox">
                        <div class="ibox-head">
                            <div class="ibox-title">REQUESTS FOR THIS COURSE</div>
                            
                        </div>
                        <div class="ibox-body">
                            <table class="table table-bordered table-hover" id="requestsTable">
                                <thead class="thead-default thead-lg">
                                    <tr>
                                        <th class="text-center">No</th>
                                        <th>Title</th>
                                        <th>Description</th>
                                        <th>Project</th>
                                        <th>Course</th>
                                        <th>Amount</th>
                                        <th class="text-center">Status</th>
                                        <th class="text-center">Attachment</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $course->requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                            <td class="title"><?php echo e($item->title); ?></td>
                                            <td class="description"><?php echo e($item->description); ?></td>
                                            <td class="project" data-value="<?php echo e($item->course->project->id); ?>"><?php if(isset($item->course->project->id)): ?><?php echo e($item->course->project->name); ?><?php endif; ?></td>
                                            <td class="course" data-value="<?php echo e($item->course_id); ?>"><?php if(isset($item->course->name)): ?><?php echo e($item->course->name); ?><?php endif; ?></td>
                                            <td class="amount"><?php echo e($item->amount); ?></td>
                                            <td class="text-center py-1">
                                                <?php switch($item->status):
                                                    case (0): ?>
                                                        <span class="badge badge-primary badge-pill">Pending</span>
                                                        <?php break; ?>
                                                    <?php case (1): ?>
                                                        <span class="badge badge-danger badge-pill">Rejected</span>
                                                        <?php break; ?>
                                                    <?php case (2): ?>
                                                        <span class="badge badge-success badge-pill">Approved</span>
                                                        <?php break; ?>
                                                    <?php default: ?>
                                                        
                                                <?php endswitch; ?>
                                            </td>
                                            <td class="attachment text-center">
                                                <?php if($item->attachment != null): ?>
                                                    <?php
                                                        $path_info = pathinfo($item->attachment);
                                                    ?>
                                                    <a href="#" data-type="<?php echo e($path_info['extension']); ?>" data-value="<?php echo e(asset($item->attachment)); ?>"><i class="fa fa-paperclip"></i><a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END PAGE CONTENT-->
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
    </div>

    <div class="modal fade" id="addModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('add.member')); ?>" method="post" id="add_form">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">
                    <div class="modal-header">
                        <h4 class="modal-title">Add New Member</h4>
                        <button type="button" class="close" data-dismiss="modal">×</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="control-label w-100">Name<span class="text-danger">*</span></label>
                            <div class="w-100">
                                <select class="form-control" id="member_select" name="members[]" multiple="multiple">
                                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item->hasCourse($course->id)): ?> <?php continue; ?> <?php endif; ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>                                                
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select> 
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">    
                        <button type="submit" class="btn btn-primary ml-2">Save</button>                       
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="imageModal">
        <div class="modal-dialog" style="margin-top:17vh">
            <div class="modal-content">
                <img src="" id="image_attach" width="500" height="600" alt="">
            </div>
        </div>
    </div>

    <div class="modal fade" id="pdfModal">
        <div class="modal-dialog modal-lg" style="margin-top:7vh">
            <div class="modal-content">
                <iframe src="" id="pdf_attach" frameborder="0" width="100%" style="height:85vh;"></iframe>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(asset('master/vendors/moment/min/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('master/vendors/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>  
    <script src="<?php echo e(asset('master/vendors/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script>
        $(document).ready(function(){

            $('#add_due_to').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true,
                format: "yyyy-mm-dd"
            });

            $("#member_select").select2();

            $("#btn-add-member").click(function(){
                $("#addModal").modal();
            });



            $(".btn-edit").click(function(){
                let id = $(this).data('id');
                let name = $(this).parents('tr').find('.name').text().trim();
                let description = $(this).parents('tr').find('.description').text().trim();
                let manager = $(this).parents('tr').find('.manager').data('value');
                let company = $(this).parents('tr').find('.company').data('value');
                let due_to = $(this).parents('tr').find('.due_to').text().trim();
                let limit = $(this).parents('tr').find('.limit').data('value');
                let progress = $(this).parents('tr').find('.prog').data('value');

                $("#edit_form .id").val(id);
                $("#edit_form .name").val(name);
                $("#edit_form .description").val(description);
                $("#edit_form .manager").val(manager);
                $("#edit_form .company").val(company);
                $("#edit_form .due_to").val(due_to);
                $("#edit_form .limit").val(limit);
                $("#edit_form .progress").val(progress);
                $("#editModal").modal();
            });

            $("td.attachment a").click(function(e){
                e.preventDefault();
                let type = $(this).data('type');
                let url = $(this).data('value');
                if (type == 'pdf') {
                    $("#pdf_attach").attr('src', url);
                    $("#pdfModal").modal();
                }else{
                    $("#image_attach").attr('src', url);
                    $("#imageModal").modal();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\TITAN\titan\resources\views/project/course_detail.blade.php ENDPATH**/ ?>