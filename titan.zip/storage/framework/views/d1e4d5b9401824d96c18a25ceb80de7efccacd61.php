<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('master/vendors/bootstrap-datepicker/dist/css/bootstrap-datepicker3.min.css')); ?>" rel="stylesheet" />    
    <link href="<?php echo e(asset('master/vendors/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('master/vendors/select2/dist/css/select2.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $role = Auth::user()->role->slug;
    ?>
    <div class="content-wrapper">
        <!-- START PAGE CONTENT-->
        <div class="page-heading">
            <h1 class="page-title">Create New Course</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/"><i class="la la-home font-20"></i></a></li>
                <li class="breadcrumb-item">Project</li>
                <li class="breadcrumb-item">Project Overview</li>
                <li class="breadcrumb-item">Create Course</li>
            </ol>
        </div>
        <div class="page-content fade-in-up">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <div class="ibox ibox-fullheight">
                        <div class="ibox-head">
                            <div class="ibox-title">New Course</div>
                        </div>
                        <form class="form-horizontal" action="<?php echo e(route('save_course')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="ibox-body">
                                <div class="form-group mb-4 row">
                                    <label class="col-sm-2 col-form-label">Name<span class="text-danger">*</span></label>
                                    <div class="col-sm-10">
                                        <input class="form-control" name="name" type="text" placeholder="Course Name" autofocus required>
                                        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="form-group mb-4 row">
                                    <label class="col-sm-2 col-form-label">Project<span class="text-danger">*</span></label>
                                    <div class="col-sm-10">
                                        <select class="form-control" name="project_id" required>
                                            <option value="">Select a project</option>
                                            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if ($errors->has('project_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('project_id'); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="form-group mb-4 row">
                                    <label class="col-sm-2 col-form-label">Description</label>
                                    <div class="col-sm-10">
                                        <textarea class="form-control" name="description" placeholder="Course Description" rows="5"></textarea>
                                    </div>
                                </div>                                
                                <div class="form-group mb-4 row">
                                    <label class="col-sm-2 col-form-label">Due Date<span class="text-danger">*</span></label>
                                    <div class="col-sm-10">
                                        <input class="form-control due_to" name="due_to" type="text" value="<?php echo e(date('Y-m-d')); ?>" autocomplete="off">
                                        <?php if ($errors->has('due_to')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('due_to'); ?>
                                            <span class="invalid-feedback d-block" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <div class="form-group mb-4 row">
                                    <label class="col-sm-2 col-form-label">Status<span class="text-danger">*</span></label>
                                    <div class="col-sm-10">
                                        <select class="form-control" name="status">
                                            <option value="1">New</option>
                                            <option value="2">In Progress</option>
                                            <option value="3">On Hold</option>
                                            <option value="4">Completed</option>
                                        </select>                                        
                                    </div>
                                </div>
                                <div class="form-group mb-4 row">
                                    <label class="col-sm-2 col-form-label">Members</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" id="member_select" name="members[]" multiple="multiple">
                                            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>                                        
                                    </div>
                                </div>
                            </div>
                            <div class="ibox-footer row">
                                <div class="col-sm-10 ml-sm-auto">
                                    <button type="submit" class="btn btn-primary mr-2" type="button">Submit</button>
                                    <button class="btn btn-secondary mr-2" type="reset">Reset</button>
                                    <a href="javascript: history.go(-1)" class="btn btn-info">Back</a>
                                </div>
                            </div>
                        </form>
                    </div>                        
                </div>
            </div>
        </div>
        <!-- END PAGE CONTENT-->
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(asset('master/vendors/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('master/vendors/moment/min/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('master/vendors/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>    
    <script src="<?php echo e(asset('master/vendors/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            $("#member_select").select2();
            $('.due_to').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true,
                format: "yyyy-mm-dd"
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\TITAN\titan\resources\views/project/create_course.blade.php ENDPATH**/ ?>