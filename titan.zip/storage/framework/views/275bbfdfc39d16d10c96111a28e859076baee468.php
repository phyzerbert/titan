<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('master/vendors/bootstrap-datepicker/dist/css/bootstrap-datepicker3.min.css')); ?>" rel="stylesheet" />    
    <link href="<?php echo e(asset('master/vendors/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $role = Auth::user()->role->slug;
    ?>
    <div class="content-wrapper">
        <!-- START PAGE CONTENT-->
        <div class="page-heading">
            <h1 class="page-title">Money Request Management</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/"><i class="la la-home font-20"></i></a></li>
                <li class="breadcrumb-item">Money Request Management</li>
            </ol>
        </div>
        <div class="page-content fade-in-up">
            <div class="ibox">
                <div class="ibox-body">                                           
                    <div class="text-right mb-4">
                        <?php if($role == 'admin' || $role == 'accountant'): ?>
                            <a href="<?php echo e(route('request.export')); ?>" id="btn-export" class="btn btn-info btn-fix"><span class="btn-icon"><i class="la la-file-excel-o"></i>Export</span></a>
                        <?php endif; ?>
                        <?php if($role == 'project_manager'): ?> 
                            <button type="button" id="btn-add" class="btn btn-primary btn-fix"><span class="btn-icon"><i class="ti-plus"></i>Add New</span></button>
                        <?php endif; ?>
                    </div>
                    <div class="table-responsive row">
                        <table class="table table-bordered table-hover" id="requestsTable">
                            <thead class="thead-default thead-lg">
                                <tr>
                                    <th class="text-center">No</th>
                                    <th>Company</th>
                                    <th>Project</th>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Course</th>
                                    <th>Amount</th>
                                    <th>Note</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Attachment</th>
                                    <?php if($role == 'admin' || $role == 'accountant'): ?>
                                        <th class="text-center">Action</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e((($data->currentPage() - 1 ) * $data->perPage() ) + $loop->iteration); ?></td>
                                        <td class="company"><?php if(isset($item->course->project->id)): ?><?php echo e($item->course->project->company->name); ?><?php endif; ?></td>
                                        <td class="project" data-value="<?php echo e($item->course->project->id); ?>"><?php if(isset($item->course->project->id)): ?><?php echo e($item->course->project->name); ?><?php endif; ?></td>
                                        <td class="title"><?php echo e($item->title); ?></td>
                                        <td class="description"><?php echo e($item->description); ?></td>
                                        <td class="course" data-value="<?php echo e($item->course_id); ?>"><?php if(isset($item->course->name)): ?><?php echo e($item->course->name); ?><?php endif; ?></td>
                                        <td class="amount"><?php echo e($item->amount); ?></td>
                                        <td class="note"><?php echo e($item->note); ?></td>
                                        <td class="text-center py-1">
                                            
                                            <?php switch($item->status):
                                                case (0): ?>
                                                    <span class="badge badge-primary badge-pill">Pending</span>
                                                    <?php break; ?>
                                                <?php case (1): ?>
                                                    <span class="badge badge-danger badge-pill">Rejected</span>
                                                    <?php break; ?>
                                                <?php case (2): ?>
                                                    <span class="badge badge-success badge-pill">Approved</span>
                                                    <?php break; ?>
                                                <?php default: ?>
                                                    
                                            <?php endswitch; ?>
                                        </td>
                                        <td class="attachment text-center">
                                            <?php if($item->attachment != null): ?>
                                                <?php
                                                    $path_info = pathinfo($item->attachment);
                                                ?>
                                                <a href="#" data-type="<?php echo e($path_info['extension']); ?>" data-value="<?php echo e(asset($item->attachment)); ?>"><i class="fa fa-paperclip"></i><a>
                                            <?php endif; ?>
                                        </td>
                                        <?php if($role == 'admin' || $role == 'accountant'): ?>
                                            <td class="text-center py-1">
                                                <a class="btn btn-sm <?php if($item->exceed == 1): ?> btn-danger <?php else: ?> btn-info <?php endif; ?> btn-fix btn-response" data-id="<?php echo e($item->id); ?>" data-exceed=<?php echo e($item->exceed); ?>><span class="btn-icon text-white"><i class="la la-comment"></i>Response</span></a>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="clearfix">
                            <div class="float-left" style="margin: 0;">
                                <p>Total <strong style="color: red"><?php echo e($data->total()); ?></strong> Requests</p>
                            </div>
                            <div class="float-right" style="margin: 0;">
                                <?php echo $data->appends([])->links(); ?>

                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
        <!-- END PAGE CONTENT-->
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>        
    </div>

    <div class="modal fade" id="addModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('request.create')); ?>" method="post" id="add_form" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h4 class="modal-title">Request Money</h4>
                        <button type="button" class="close" data-dismiss="modal">×</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="control-label text-right mt-1">Title<span class="text-danger">*</span></label>
                            <input class="form-control" type="text" name="title" id="add_title" placeholder="Reqeust Title" required>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Project<span class="text-danger">*</span></label>
                            <select name="project_id" id="add_project" class="form-control">
                                <option value="">Select a project</option>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Course<span class="text-danger">*</span></label>
                            <select name="course_id" id="add_course" class="form-control">
                            </select>
                        </div>                        
                        <div class="form-group">
                            <label class="control-label text-right mt-1">Description</label>
                            <input class="form-control" type="text" name="description" id="add_description" placeholder="Description">
                        </div>                        
                        <div class="form-group">
                            <label class="control-label text-right mt-1">Amount<span class="text-danger">*</span></label>
                            <input class="form-control" type="number" name="amount" id="add_amount" placeholder="Amount" required>
                        </div>                        
                        <div class="form-group">
                            <label class="control-label text-right mt-1">Attachment</label>
                            <input class="form-control form-control-sm" type="file" name="attachment" id="add_attachment" accept="image/*, application/pdf">
                        </div>
                    </div>
                    
                    <div class="modal-footer">    
                        <button type="submit" class="btn btn-primary">Save</button>                       
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="responseModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('request.response')); ?>" method="post" id="response_form">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h4 class="modal-title">Response To Money Request</h4>
                        <button type="button" class="close" data-dismiss="modal">×</button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="id" id="response_id">
                        <div class="form-group">
                            <label class="control-label text-right mt-1">Company</label>
                            <input class="form-control" type="text" name="company" id="response_company" readonly />
                        </div>
                        <div class="form-group">
                                <label class="control-label text-right mt-1">Project Name</label>
                                <input class="form-control" type="text" name="project" id="response_project" readonly />
                            </div>
                        <div class="form-group">
                            <label class="control-label text-right mt-1">Title</label>
                            <input class="form-control" type="text" name="title" id="response_title" placeholder="Reqeust Title" readonly required>
                        </div>                        
                        <div class="form-group">
                            <label class="control-label text-right mt-1">Amount</label>
                            <input class="form-control" type="number" name="amount" id="response_amount" placeholder="Amount" readonly required>
                        </div>
                        <div class="form-group">
                            <label class="control-label">Response<span class="text-danger">*</span></label>
                            <select name="status" id="add_response" class="form-control">
                                <option value="0">Pending</option>
                                <option value="1">Reject</option>
                                <option value="2">Approve</option>
                            </select>
                        </div> 
                        <div class="form-group">
                            <label class="control-label text-right mt-1">Note</label>
                            <input class="form-control" type="text" name="note" id="response_note" placeholder="Response Note">
                        </div> 
                    </div>
                    
                    <div class="modal-footer">    
                        <button type="submit" class="btn btn-primary">Save</button>                       
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="imageModal">
        <div class="modal-dialog" style="margin-top:17vh">
            <div class="modal-content">
                <img src="" id="image_attach" width="500" height="600" alt="">
            </div>
        </div>
    </div>

    <div class="modal fade" id="pdfModal">
        <div class="modal-dialog modal-lg" style="margin-top:7vh">
            <div class="modal-content">
                <iframe src="" id="pdf_attach" frameborder="0" width="100%" style="height:85vh;"></iframe>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(asset('master/vendors/moment/min/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('master/vendors/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script> 
    <script>
        $(document).ready(function(){
            var user_role = '<?php echo e(Auth::user()->role->slug); ?>';
            $('#add_due_to').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true,
                format: "yyyy-mm-dd"
            });

            $("#btn-add").click(function(){
                $("#addModal").modal();
            });

            $("#add_project").change(function(){
                let project_id = $(this).val();
                if(project_id == '') return false;
                $.ajax({
                    url: "<?php echo e(route('get_courses')); ?>",
                    data: {project_id: project_id},
                    type: "post",
                    dataType: "json",
                    success: function(data){
                        $("#add_course").html('');
                        for (let i = 0; i < data.length; i++) {
                            const element = data[i];
                            $("#add_course").append(`
                                <option value="${element.id}">${element.name}</option>
                            `);
                        };
                    }
                })
            });

            $(".btn-response").click(function(){
                let id = $(this).data('id');
                let title = $(this).parents('tr').find('.title').text().trim();
                let company = $(this).parents('tr').find('.company').text().trim();
                let project = $(this).parents('tr').find('.project').text().trim();
                let amount = $(this).parents('tr').find('.amount').text().trim();
                let note = $(this).parents('tr').find('.note').text().trim();
                let exceed = $(this).data('exceed');
                // if((exceed == "1" && user_role != 'admin') || (exceed != "1" && user_role != 'accountant')){
                if((exceed == "1" && user_role != 'admin')){
                // if(exceed != "1" && user_role != 'accountant'){
                    alert("You can' t respond to exceed limit request");
                    return false;
                }
                $("#response_id").val(id);
                $("#response_company").val(company);
                $("#response_project").val(project);
                $("#response_title").val(title);
                $("#response_amount").val(amount);
                $("#response_note").val(note);
                $("#responseModal").modal();
            });

            $("td.attachment a").click(function(e){
                e.preventDefault();
                let type = $(this).data('type');
                let url = $(this).data('value');
                if (type == 'pdf') {
                    $("#pdf_attach").attr('src', url);
                    $("#pdfModal").modal();
                }else{
                    $("#image_attach").attr('src', url);
                    $("#imageModal").modal();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\TITAN\titan\resources\views/project/request.blade.php ENDPATH**/ ?>